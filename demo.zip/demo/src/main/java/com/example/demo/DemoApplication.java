package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	
	
	int newInt=0;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		DemoApplication demo= new DemoApplication();
		System.out.println("The number is palindrome "+demo.checkPalindrome(12321));
		
	}
	
	public boolean checkPalindrome(int a) {
		String rev="";
	int size=String.valueOf(a).length();
	String firstHalf= String.valueOf(a).substring(0, size/2);
	String secondHalf= String.valueOf(a).substring(size-firstHalf.length());
		
	for(int j=secondHalf.length();j>0;j--) {
		rev=rev+secondHalf.charAt(j-1);
	}
		return firstHalf.equals(rev);
	}

}
